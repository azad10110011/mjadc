(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,84004,t=>{"use strict";t.i(3374),t.i(39),t.i(58234),t.i(30539),t.s([])},77043,t=>{"use strict";let e=(0,t.i(56420).default)("printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]);t.s(["Printer",0,e],77043)},72382,t=>{"use strict";let e=(0,t.i(56420).default)("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);t.s(["Eye",0,e],72382)},71043,t=>{"use strict";var e=t.i(43476),a=t.i(71645);t.i(84004);var l=t.i(30539);t.i(16787);var s=t.i(59544),c=t.i(39964),n=t.i(49744),i=t.i(96640),r=t.i(32098),o=t.i(9165),d=t.i(77043),u=t.i(72382);t.s(["default",0,function(){let[t,m]=(0,a.useState)([]),[h,p]=(0,a.useState)(!0),[y,b]=(0,a.useState)(!1),[x,g]=(0,a.useState)([]),[f,k]=(0,a.useState)(""),[j,v]=(0,a.useState)(!1),$=(0,a.useRef)(null);(0,a.useEffect)(()=>{o.api.get("/exam-controller/results/pending").then(t=>m(t.data||[])).catch(()=>{}).finally(()=>p(!1))},[]);let C=async(t,e,a)=>{k(`${t} - ${e} (${a})`),v(!0),b(!0);try{let l=await o.api.get(`/exam-controller/results/detail?exam_name=${encodeURIComponent(t)}&subject=${encodeURIComponent(e)}&class=${encodeURIComponent(a)}`);g((l.data||[]).map((t,e)=>({...t,sl:e+1,mcq:t.mcq??0,cq:t.cq??0,practical:t.practical??0,total:t.total??0,gpa:t.gpa??0})))}catch{g([])}finally{v(!1)}},w=async(t,e,a)=>{try{await o.api.post("/exam-controller/results/approve-batch",{exam_name:t,subject:e,class:a}),alert("Results approved");let l=await o.api.get("/exam-controller/results/pending");m(l.data||[])}catch(t){alert(t.message)}},_=async(t,e,a)=>{if(confirm(`Send all ${e} results back to teacher for ${a}?`))try{await o.api.post("/exam-controller/results/back-to-teacher",{exam_name:t,subject:e,class:a}),alert("Results returned to teacher");let l=await o.api.get("/exam-controller/results/pending");m(l.data||[])}catch(t){alert(t.message)}},N=t.map(t=>{let a="approved"===t.status;return{exam_name:t.exam_name,subject:t.subject,class:t.class,student_count:t.student_count,status:(0,e.jsx)(i.Badge,{variant:"submitted"===t.status?"info":a?"success":"warning",children:t.status}),actions:(0,e.jsxs)("div",{className:"flex gap-2",children:[(0,e.jsx)(s.Button,{size:"sm",variant:"ghost",onClick:()=>C(t.exam_name,t.subject,t.class),children:(0,e.jsx)(u.Eye,{className:"h-3.5 w-3.5"})}),!a&&(0,e.jsx)(s.Button,{size:"sm",variant:"primary",onClick:()=>w(t.exam_name,t.subject,t.class),children:"Approve"}),(0,e.jsx)(s.Button,{size:"sm",variant:"secondary",onClick:()=>_(t.exam_name,t.subject,t.class),children:"Back to Teacher"})]})}});return(0,e.jsxs)(l.PanelLayout,{role:"exam_controller",title:"Approve Result",children:[(0,e.jsx)(c.Card,{children:(0,e.jsx)(c.CardContent,{className:"pt-6",children:(0,e.jsx)(n.DataTable,{columns:[{key:"exam_name",label:"Exam Name"},{key:"subject",label:"Subject"},{key:"class",label:"Class"},{key:"student_count",label:"Students"},{key:"status",label:"Status"},{key:"actions",label:"Actions"}],data:N,emptyMessage:"No pending results for approval",loading:h})})}),(0,e.jsx)(r.Modal,{open:y,onClose:()=>b(!1),title:f,children:(0,e.jsxs)("div",{ref:$,children:[(0,e.jsx)("div",{className:"mb-3 flex justify-end",children:(0,e.jsxs)(s.Button,{size:"sm",variant:"secondary",onClick:()=>{let t=window.open("","_blank");t&&(t.document.write(`
      <html><head><title>${f}</title>
      <style>
        body { font-family: 'Times New Roman', Times, serif; padding: 20px; }
        h2 { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { border: 1px solid black; padding: 4px 6px; text-align: center; }
        th { background: #f0f0f0; font-weight: bold; }
        .left { text-align: left; }
      </style></head><body>
      <h2>${f}</h2>
      <table>
        <thead><tr>
          <th>SL No</th><th>Roll</th><th class="left">Name</th><th>MCQ</th><th>CQ</th><th>Practical</th><th>Total</th><th>Grade</th><th>GPA</th>
        </tr></thead>
        <tbody>
          ${x.map(t=>`
            <tr>
              <td>${t.sl}</td>
              <td>${t.student_id}</td>
              <td class="left">${t.name}</td>
              <td>${t.mcq}</td>
              <td>${t.cq}</td>
              <td>${t.practical}</td>
              <td>${t.total}</td>
              <td>${t.grade}</td>
              <td>${t.gpa}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
      </body></html>
    `),t.document.close(),t.print())},children:[(0,e.jsx)(d.Printer,{className:"mr-1 h-4 w-4"})," Print"]})}),(0,e.jsx)(n.DataTable,{columns:[{key:"sl",label:"SL No"},{key:"student_id",label:"Roll"},{key:"name",label:"Name"},{key:"mcq",label:"MCQ"},{key:"cq",label:"CQ"},{key:"practical",label:"Practical"},{key:"total",label:"Total"},{key:"grade",label:"Grade"},{key:"gpa",label:"GPA"}],data:x,loading:j,emptyMessage:"No data found"})]})})]})}])}]);