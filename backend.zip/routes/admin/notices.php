<?php

$adminMw = function () { Auth::requireRole('admin'); };

// GET /api/admin/notices
$router->get('/api/admin/notices', function () {
    Auth::requireRole('admin');
    $notices = Database::fetchAll(
        "SELECT n.*, u.name as author FROM notices n 
         JOIN users u ON n.created_by = u.id 
         ORDER BY n.created_at DESC"
    );
    Response::success($notices);
}, [$adminMw]);

// POST /api/admin/notices
$router->post('/api/admin/notices', function () {
    $user = Auth::requireRole('admin');
    $data = json_decode(file_get_contents('php://input'), true);
    validate($data)->required('title', 'Title')->validate();

    $noticeId = Database::insert('notices', [
        'title' => $data['title'],
        'body' => $data['body'] ?? '',
        'status' => $data['status'] ?? 'draft',
        'published_at' => ($data['status'] ?? 'draft') === 'published' ? date('Y-m-d H:i:s') : null,
        'created_by' => $user['id'],
    ]);

    if (isset($_FILES['pdf']) && $_FILES['pdf']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['pdf']['name'], PATHINFO_EXTENSION);
        $filename = "notice_{$noticeId}.{$ext}";
        move_uploaded_file($_FILES['pdf']['tmp_name'], __DIR__ . "/../../uploads/notices/{$filename}");
        Database::update('notices', ['pdf_path' => "uploads/notices/{$filename}"], 'id = ?', ['id' => $noticeId]);
    }

    Response::created(['id' => $noticeId], 'Notice created');
}, [$adminMw]);

// PUT /api/admin/notices/{id}
$router->put('/api/admin/notices/{id}', function (array $params) {
    Auth::requireRole('admin');
    $data = json_decode(file_get_contents('php://input'), true);
    $updateData = [];
    foreach (['title', 'body', 'status'] as $f) {
        if (isset($data[$f])) $updateData[$f] = $data[$f];
    }
    if (!empty($updateData)) {
        Database::update('notices', $updateData, 'id = ?', ['id' => $params['id']]);
    }
    Response::success(null, 'Notice updated');
}, [$adminMw]);

// DELETE /api/admin/notices/{id}
$router->delete('/api/admin/notices/{id}', function (array $params) {
    Auth::requireRole('admin');
    Database::delete('notices', 'id = ?', [$params['id']]);
    Response::success(null, 'Notice deleted');
}, [$adminMw]);
